package main;

import gui.LoginFrame;

public class Main {
    public static void main(String[] args) {
        new LoginFrame();
    }
}
